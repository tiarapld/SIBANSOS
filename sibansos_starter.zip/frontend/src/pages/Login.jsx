import React, { useState } from 'react'
import API, { setAuthToken } from '../api/api'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const navigate = useNavigate()

  async function submit(e) {
    e.preventDefault()
    try {
      const res = await API.post('/auth/login', { username, password })
      const { token } = res.data
      localStorage.setItem('sibansos_token', token)
      setAuthToken(token)
      navigate('/dashboard')
    } catch (err) {
      alert(err.response?.data?.message || 'Login failed')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={submit} className="bg-white p-6 rounded shadow w-full max-w-md">
        <h2 className="text-xl font-semibold mb-4">Login Admin</h2>
        <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" className="w-full mb-2 p-2 border rounded" />
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" className="w-full mb-4 p-2 border rounded" />
        <button className="w-full bg-blue-600 text-white py-2 rounded">Masuk</button>
      </form>
    </div>
  )
}
