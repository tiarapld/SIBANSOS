import React, { useEffect, useState } from 'react'
import API, { setAuthToken } from '../api/api'
import RecipientsTable from '../components/RecipientsTable'
import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
  const navigate = useNavigate()
  const [recipients, setRecipients] = useState([])

  useEffect(() => {
    const token = localStorage.getItem('sibansos_token')
    if (!token) return navigate('/login')
    setAuthToken(token)
    load()
  }, [])

  async function load() {
    try {
      const res = await API.get('/recipients')
      setRecipients(res.data)
    } catch (err) {
      console.error(err)
      if (err.response?.status === 401) navigate('/login')
    }
  }

  return (
    <div className="p-6 min-h-screen bg-gray-100">
      <header className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold">SIBANSOS Dashboard</h1>
        <button onClick={()=>{ localStorage.removeItem('sibansos_token'); navigate('/login') }} className="py-1 px-3 border rounded">Logout</button>
      </header>
      <section>
        <RecipientsTable data={recipients} onRefresh={load}/>
      </section>
    </div>
  )
}
