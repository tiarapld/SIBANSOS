import React from 'react'
import API from '../api/api'

export default function RecipientsTable({ data, onRefresh }) {
  async function handleDelete(id) {
    if (!confirm('Hapus data ini?')) return;
    try {
      await API.delete(`/recipients/${id}`);
      onRefresh();
    } catch (err) {
      alert('Gagal menghapus');
    }
  }

  return (
    <div className="bg-white rounded shadow p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-semibold">Daftar Penerima</h2>
      </div>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left border-b">
            <th className="py-2">Nama</th>
            <th>NIK</th>
            <th>Jenis Bantuan</th>
            <th>Alamat</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.map(r => (
            <tr key={r.id} className="border-b">
              <td className="py-2">{r.name}</td>
              <td>{r.nik}</td>
              <td>{r.assistance_type}</td>
              <td>{r.address}</td>
              <td>
                <button onClick={()=>handleDelete(r.id)} className="px-2 py-1 text-xs bg-red-500 text-white rounded">Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
