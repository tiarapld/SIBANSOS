# SIBANSOS Starter Project

This is a starter full-stack project for the SIBANSOS (Sistem Informasi Bantuan Sosial) assignment.

## What inside
- backend: Node.js + Express, MySQL
- frontend: React + Vite + Tailwind CSS

## Quick steps
1. Import `backend/schema.sql` into your MySQL server.
2. Create `.env` in backend using `.env.example`.
3. Install backend: `cd backend && npm install` and run `npm run dev`.
4. Install frontend: `cd frontend && npm install` and run `npm run dev`.

Note: For Tailwind, follow the official Tailwind + Vite setup to initialize `tailwind.config.cjs` if needed.
